<div class="last-section">
	<div class="team-heading">
		<h2> Contacts </h2>
	</div>
	<div class="row">
		<div class="card-wrapper wow fadeInUp" data-wow-duration="0.5s">
			<div class="card">
				<div class="card-img suresh"></div>
				<div class="card-details">
					<h2>P. Suresh Babu </h2>
					<div class="inner">
						<span class="ocp">&#128100; Staff Coordinator</span><br>
						<span class="phn">&#9742; 7382352503</span><br>
						<span class="eml">&#9993; naveen_nnk9@yahoo.co.in</span><br>
					</div>
				</div> <!-- Card details -->
			</div><!-- Card -->
		</div><!-- Card Wrapper -->
		<div class="card-wrapper wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.3s">
			<div class="card">
				<div class="card-img naveen"></div>
				<div class="card-details">
					<h2> N. Naveen Kumar </h2>
					<div class="inner">
						<span class="ocp">&#128100; Student Coordinator</span><br>
						<span class="phn">&#9742; 7382352503</span><br>
						<span class="eml">&#9993; naveen_nnk9@yahoo.co.in</span><br>
					</div>
				</div> <!-- Card details -->
			</div><!-- Card -->
		</div><!-- Card Wrapper -->
		<div class="card-wrapper wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.7s">
			<div class="card">
				<div class="card-img ramana"></div>
				<div class="card-details">
					<h2> S. Ramana Reddy </h2>
					<div class="inner">
						<span class="ocp">&#128100; Student Coordinator</span><br>
						<span class="phn">&#9742; 9553703647</span><br>
						<span class="eml">&#9993; ramanareddysane</span><br>
					</div>
				</div> <!-- Card details -->
			</div><!-- Card -->
		</div><!-- Card Wrapper -->
		<div class="card-wrapper wow fadeInDown" data-wow-duration="0.5s"  data-wow-delay="0.5s">
			<div class="card">
				<div class="card-img surya"></div>
				<div class="card-details">
					<h2> P. Surya Teja </h2>
					<div class="inner">
						<span class="ocp">&#128100; Student Coordinator</span><br>
						<span class="phn">&#9742; 7382352503</span><br>
						<span class="eml">&#9993; naveen_nnk9@yahoo.co.in</span><br>
					</div>
				</div> <!-- Card details -->
			</div><!-- Card -->
		</div><!-- Card Wrapper -->

		
	</div>
</div>