
<div id="top-left">
	<h1 id="heading">Gallery</h1>
	 	<img src="img/img-2.jpg" class="wow fadeInRight sample"
	 				data-wow-delay="0.4s"  data-wow-duration="1s" id="sample-2">
	 	<img src="img/img-1.jpg" class="wow fadeInLeft sample"
	 				data-wow-delay="0.4s" data-wow-duration="1s" id="sample-4">
	 	<img src="img/img-3.jpg" class="wow fadeInRight sample"
	 				data-wow-delay="0.8s" data-wow-duration="1s" id="sample-3">
	 	<img src="img/img-4.jpg" class="wow fadeInRight sample"
	 				data-wow-delay="1.2s"    data-wow-duration="1s"id="sample-1">
	 	<img src="img/img-5.jpg" class="wow fadeInLeft sample"
	 				data-wow-delay="0.8s" data-wow-duration="1s" id="sample-5">
	 	<img src="img/img-6.jpg" class="wow fadeInRight sample"
	 				data-wow-delay="1.4s" data-wow-duration="1s" id="sample-6">
	 	<img src="img/img-7.jpg" class="wow fadeInLeft sample"
	 				data-wow-delay="1.2s"    data-wow-duration="1s"id="sample-7">
	 	<img src="img/img-8.jpg" class="wow fadeInLeft sample"
	 				data-wow-delay="1.4s" data-wow-duration="1s" id="sample-8">

</div>

<div id="bottom-right">
	<nav class="cl-effect-10 wow bounceInLeft" data-wow-delay="1.4s" wow-iteration="3">
		<a href="gallery/" data-hover="Go"><span>Wanna see</span></a>
	</nav>
</div>