<div id="events-slider">
			<div class="cd-slider-wrapper">
				<ul class="cd-slider">
					<li class="is-visible">
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content pappt" >
								<h3>Unleash your innovation and technical skill</h3>
								<h3>on a single platform With our</h3>
								<h2>PAPER PRESENTATION.</h2>
								<h3>This is a flourishing opportunity to present your work <br>
									And to innovate your academic focus.</h3>
								<h3>Get a great experience as your innovation, knowledge <br>
									and aptitude will be evaluated by an exceptional judging panel.</h3>							
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li >
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content">
							<div class="event-content">
								<h3>Wanna become a real source to spot the erratic behaviour</h3>
								<h3>Run into the culture of “zero-defect” with our</h3>
								<h2>DIG 'D' BUG</h2>
								<h3>Have a great Code walkthrough Elate<br>
									 your jazz and find the flaw...</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content">
							<div class="event-content">
								<h3>Are you a coding freak?<br>
									Are u fervent to expo your stuff?</h3>
								<h3>Here is an opportunity to enrich your coding skills. <br>
									As we present our</h3>
								<h2>CODE MARATHON</h2>
								<h3>to fulfil your zest…<br>
									So, get ready to invade the code world.</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content">
							<div class="event-content">
								<h3>Zeal to unriddle the riddles… Crazy about solving brain twisters…</h3>
								<h3>Agog to untangle the puzzles… Then join us in </h3> 
								<h2>ENIGMA</h2>
								<h3>An excellent event to thrill you <br>
								 and to enhance your thinking power.</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content">
								<h3>Quiz team competitions are often viewed as <br>
								 the pursuit of trivial technical knowledge.</h3>
								<h3>Encourages students to achieve academic excellence.Our <h2>BEAT 'D' CLOCK</h2></h3> 
								<h3>Empowers students with a new understanding of what has been, 
									what is now and what can be in the technical field.</h3>
								<h3>Participate, test your knowledge and learn new things.</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content">
								<h2>CORTOFLICKS</h2>
								<h3>A classic first stage for the new film makers like you to reach the <br>
									audience. Our event inculcates and channelizes the exuberance of</h3>
								<h3> the youth by providing them a massive platform to prove their worth,<br>
									giving them a pragmatic exposure to the real world challenge.</h3>
								<h3>Apply the creativity to your style and make it aesthetically pleasing…</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content">
								<h3>“The purpose of Visualisation is insight not pictures”<br>
									Following the quote, We are here to give you a vivacious platform to</h3>
								<h3>show case your ability to put forward your views with our </h3>
								<h2>SKETCH IT OUT</h2>
								<h3>So, bring out your insights with a vibrant visual presentation.<br> And have a great discussion with experts.</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content">
								<h2>FOTOGRAFIA</h2>
								<h3>Zoom your creativity and composition skills Through our<br>
								 Fotographia A platform to exhibit your excellence and supremacy.</h3>
								<h3>So, hurry up folks, Pick your camera <br>
								 to encounter the essence of excitement. </h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div class="event-content">
 								<h2>GAME ZONE</h2> 
								<h3>Be an audacious fighter, hold the gun, master the game and</h3>
								<h3>be the hero of our gaming world.</h3>
								<h3> We put forward an exhilarating platform GAME ZONE</h2> 
 								<h3>To people like you, going nuts about gaming.</h3>
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
					<li>
						<div class="cd-half-block image"></div>
						<div class="cd-half-block content light-bg">
							<div>
								<h2>ECSTASY</h2>
								
							</div>
						</div> <!-- .cd-half-block.content -->
					</li>
				</ul> <!-- .cd-slider -->
			</div> <!-- .cd-slider-wrapper -->
		</div>