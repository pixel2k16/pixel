
$(".videoContainer").hide();
$(document).ready(function(){
	$(".videoContainer").show();
});