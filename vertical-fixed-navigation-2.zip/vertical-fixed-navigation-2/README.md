Vertical Fixed Navigation #2
=========

A smart vertical navigation, with round indicators that turn into labelled icons when the user interacts with them.

[Article on CodyHouse](https://codyhouse.co/gem/vertical-fixed-navigation-2/)

[Demo](https://codyhouse.co/demo/vertical-fixed-navigation-2/index.html)
 
[Terms](https://codyhouse.co/terms/)
